package invoice;

public interface Pay {
    public double getPaymentAmount();
}
