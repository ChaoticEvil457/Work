The complete solution was published by Charles L. Bouton in 1902
I wouldn't say that nim is present in popular culture today (I've literally never heard of it)
But many combinatorial games are popular today such as Tic Tac Toe and Connect Four