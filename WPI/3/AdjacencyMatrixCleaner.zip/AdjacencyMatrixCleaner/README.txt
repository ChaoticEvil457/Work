Steps:
1) Format your adjacency matrix such that it has an equal number of columns and rows (using enter key)
2) Paste the adjacency matrix into data.txt
3) Run cleanAdjacencyMatrix.exe
4) Your output will appear in output.txt

foramt:

p (#of vertices) (#of edges) -> displays the number of edges and vertices in the graph
e (vertex 1) (vertex 2)      -> represents an edge connecting vertices 1 and 2