package Lab4;

public class Main {
    public static void main(String[] args){
        VoteBooth v = new VoteBooth();
        v.screen();
        System.out.println(v.voteD.longestStreak("Husky"));

    }
}
