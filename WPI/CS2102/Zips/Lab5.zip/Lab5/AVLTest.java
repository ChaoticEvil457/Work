public class AVLTest implements ISet{

    public AVLTest(){}//empty class for the purposes of checking things

    @Override
    public ISet addElt(String s) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean hasElt(String s) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public int size() {
        // TODO Auto-generated method stub
        return 0;
    }
    
}
