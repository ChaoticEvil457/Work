package Lab1;

public class Album {
    String artist;
    String genre;
    public Album(String artist, String genre){
        this.artist = artist;
        this.genre = genre;
    }
}
