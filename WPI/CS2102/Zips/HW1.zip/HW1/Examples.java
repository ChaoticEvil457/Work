import org.junit.Test;
import static org.junit.Assert.*;

public class Examples {
    /*
     * Consists of two Literarians a and b
     * a has 10 nonfiction and fiction books read and a goal of 1 per day
     * b has 0 and a goal of 10 per day
     * a has 0 words written by nov 20
     * b has 10000 words written by nov 20
     * Literarian c is a copy of a used for checking duplicate cases
     */

    BooksRead aRead = new BooksRead(10);
    BooksRead bRead = new BooksRead(0);
    ReadingResult readResulta = new ReadingResult(1, aRead, aRead);
    ReadingResult readResultb = new ReadingResult(10, bRead, bRead);

    WritingResult writeResulta = new WritingResult(0, 20);
    WritingResult writeResultb = new WritingResult(10000, 20);

    ChallengeResult aResult = new ChallengeResult(readResulta, writeResulta);
    ChallengeResult bResult = new ChallengeResult(readResultb, writeResultb);

    Literarian a = new Literarian(aResult);
    Literarian b = new Literarian(bResult);
    Literarian c = new Literarian(aResult);

    public Examples() {
    }

    @Test
    public void testAverageReada() {// average books per day
        assertEquals(20.0 / 31.0, readResulta.averagePerDay(), 0.01);
    }

    @Test
    public void testAverageReadb() {
        assertEquals(0, readResultb.averagePerDay(), 0.01);
    }

    @Test
    public void testDiffGoalReada() {// difference from reading goal
        assertEquals(11.0 / 31.0, readResulta.differenceFromGoal(), 0.01);
    }

    @Test
    public void testDiffGoalReadb() {
        assertEquals(10, readResultb.differenceFromGoal(), 0.01);
    }

    @Test
    public void testAverageWritea() {// average words per day
        assertEquals(0, writeResulta.averagePerDay(), 0.01);
    }

    @Test
    public void testAverageWriteb() {
        assertEquals(10000 / 20, writeResultb.averagePerDay(), 0.01);
    }

    @Test
    public void testDiffGoalWritea() {// difference from writing goal
        assertEquals(50000 / 11.0, writeResulta.differenceFromGoal(), 0.01);
    }

    @Test
    public void testDiffGoalWriteb() {
        assertEquals(40000 / 11.0, writeResultb.differenceFromGoal(), 0.01);
    }

    @Test
    public void testHowClosea() {// how close the literarian is to their goal
        assertEquals(50000 / 11.0 + 11.0 / 31 * 10000, aResult.howClose(), 0.01);
    }

    @Test
    public void testHowCloseb() {
        assertEquals(100000 + 40000 / 11.0, bResult.howClose(), 0.01);
    }

    @Test
    public void testAbeatsBRead() {// a is better at reading than b
        assertEquals(true, a.betterBookworm(b));
    }

    @Test
    public void testBbeatsARead() {// b is worse at reading than a
        assertEquals(false, b.betterBookworm(a));
    }

    @Test
    public void testAbeatsBWrite() {// a is worse at writing than b
        assertEquals(false, a.wittierWordsmith(b));
    }

    @Test
    public void testBbeatsAWrite() {// b is better at writing than a
        assertEquals(true, b.wittierWordsmith(a));
    }

    @Test
    public void testAbeatsBScholar() {// a beats b at reading
        assertEquals(true, a.successfulScholar(b));
    }

    @Test
    public void testBbeatsAScholar() {// b beats a at writing
        assertEquals(true, b.successfulScholar(a));
    }

    @Test
    public void testCbeatsAScholar() {// duplicate returns false
        assertEquals(false, c.successfulScholar(a));
    }

}
