public class BooksRead {
    double read;// number of books read

    public BooksRead(double read) {// constructor for BooksRead
        this.read = read;
    }
}
