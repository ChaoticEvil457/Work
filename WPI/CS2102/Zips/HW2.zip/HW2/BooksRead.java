package HW2;
public class BooksRead {
    double read;// number of books read
    String genre;
    boolean skimmed;

    public BooksRead(double read, String genre, boolean skimmed) {// constructor for BooksRead
        this.read = read;
        this.genre = genre;
        this.skimmed = skimmed;
    }
}
